#include "stm32u5xx_hal.h"  // Our STM chip
#include <stdint.h>

/* MS8607 I2C Addresses */
#define MS8607_I2C_ADDRESS_PRESSURE   0x76  // 7-bit I2C address for pressure/temp
#define MS8607_I2C_ADDRESS_HUMIDITY   0x40  // 7-bit I2C address for humidity

/* MS8607 Commands */
#define MS8607_RESET_COMMAND          0x1E  // Reset command for pressure sensor
#define MS8607_PROM_READ_BASE         0xA0  // PROM read start address
#define MS8607_CONVERT_D1_COMMAND     0x40  // Convert D1 (pressure) command
#define MS8607_CONVERT_D2_COMMAND     0x50  // Convert D2 (temperature) command
#define MS8607_READ_ADC               0x00  // Read ADC result command

#define MS8607_HUMIDITY_MEASURE_HOLD  0xE5  // Hold master mode humidity measure
#define MS8607_HUMIDITY_MEASURE_NOHOLD 0xF5  // No hold mode humidity measure

/* Function Prototypes */
void MS8607_Init(I2C_HandleTypeDef *hi2c);
void MS8607_Reset(I2C_HandleTypeDef *hi2c);
void MS8607_ReadPROM(I2C_HandleTypeDef *hi2c, uint16_t *prom);
uint32_t MS8607_ReadADC(I2C_HandleTypeDef *hi2c);
float MS8607_ReadTemperature(I2C_HandleTypeDef *hi2c, uint16_t *prom);
float MS8607_ReadPressure(I2C_HandleTypeDef *hi2c, uint16_t *prom, float temperature);
float MS8607_ReadHumidity(I2C_HandleTypeDef *hi2c);

